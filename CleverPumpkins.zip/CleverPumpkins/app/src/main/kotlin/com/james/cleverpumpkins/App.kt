package com.james.cleverpumpkins

import android.app.Application
import com.james.cleverpumpkins.di.AppComponent
import com.james.cleverpumpkins.di.AppModule
import com.james.cleverpumpkins.di.DaggerAppComponent
import com.james.cleverpumpkins.di.NetworkModule
import io.realm.Realm
import io.realm.RealmConfiguration
import io.realm.rx.RealmObservableFactory

open class App : Application() {

    companion object {

        lateinit var appComponent: AppComponent
    }

    override fun onCreate() {
        super.onCreate()
        Realm.init(this)
        RealmConfiguration.Builder()
                .deleteRealmIfMigrationNeeded()
                .rxFactory(RealmObservableFactory())
                .build()

        appComponent = DaggerAppComponent.builder()
                .appModule(AppModule(this))
                .networkModule(NetworkModule())
                .build()
    }
}