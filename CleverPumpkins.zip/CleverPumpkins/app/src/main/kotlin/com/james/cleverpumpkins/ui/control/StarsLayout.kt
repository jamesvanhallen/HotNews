package com.james.cleverpumpkins.ui.control

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.james.cleverpumpkins.R
import com.james.cleverpumpkins.hide
import com.james.cleverpumpkins.show

class StarsLayout : LinearLayout {

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    fun showStars(count: Int) {
        removeAllViews()
        if (count == 0) hide() else show()
        for (a in 0..count - 1) {
            val star = LayoutInflater.from(context).inflate(R.layout.star, this, false)
            addView(star)
        }
    }
}
