package com.james.cleverpumpkins.ui.activity

import android.os.Bundle
import com.arellomobile.mvp.MvpAppCompatActivity
import com.james.cleverpumpkins.R
import com.james.cleverpumpkins.replaceFragment
import com.james.cleverpumpkins.ui.fragment.HotelsListFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : MvpAppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener { onBackPressed() }

        if (supportFragmentManager.findFragmentById(R.id.main_container) == null) {
            replaceFragment(HotelsListFragment.newInstance())
        }
    }
}
