package com.james.cleverpumpkins

import android.content.Context
import retrofit2.adapter.rxjava.HttpException
import java.io.IOException

fun httpErrorHandler(context: Context, throwable: Throwable): String = when (throwable) {
    is IOException -> context.getString(R.string.server_error)
    else -> throwable.message ?: context.getString(R.string.unknown_error)
}