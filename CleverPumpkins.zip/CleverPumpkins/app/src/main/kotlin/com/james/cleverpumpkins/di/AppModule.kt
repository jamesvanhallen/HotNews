package com.james.cleverpumpkins.di

import android.content.SharedPreferences
import android.preference.PreferenceManager
import com.james.cleverpumpkins.App
import dagger.Module
import dagger.Provides
import io.realm.Realm
import rx.Scheduler
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import javax.inject.Named
import javax.inject.Singleton

@Module
class AppModule(private val app: App) {

    companion object {

        const val MAIN_SCHEDULER = "main"
        const val IO_SCHEDULER = "io"
    }

    @Provides
    @Singleton
    fun getApp(): App {
        return app
    }

    @Provides
    @Singleton
    fun getDB(): Realm {
        return Realm.getDefaultInstance()
    }

    @Provides
    @Singleton
    fun getPrefs(app: App): SharedPreferences {
        return PreferenceManager.getDefaultSharedPreferences(app)
    }

    @Provides
    @Named(MAIN_SCHEDULER)
    @Singleton
    fun provideUIScheduler(): Scheduler {
        return AndroidSchedulers.mainThread()
    }

    @Provides
    @Named(IO_SCHEDULER)
    @Singleton
    fun provideIOScheduler(): Scheduler {
        return Schedulers.io()
    }
}