package com.james.cleverpumpkins.api

import com.james.cleverpumpkins.mvp.model.Hotel
import retrofit2.http.GET
import retrofit2.http.Path
import rx.Single

interface Api {

    @GET("0777.json")
    fun getHotelsList(): Single<List<Hotel>>

    @GET("{path}")
    fun getHotel(@Path("path") id: String): Single<Hotel>

}