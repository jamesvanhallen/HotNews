package com.james.cleverpumpkins.mvp.model.deserializer

import com.google.gson.Gson
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.james.cleverpumpkins.mvp.model.Hotel
import java.lang.reflect.Type

class HotelsDeserializer : JsonDeserializer<Hotel> {
    override fun deserialize(json: JsonElement?, typeOfT: Type?, context: JsonDeserializationContext?): Hotel {
        val hotel = Gson().fromJson(json, Hotel::class.java)
        val split = hotel.suits.split(':')
        hotel.suitsCount = split.size
        return hotel
    }
}