package com.james.cleverpumpkins

class Const {

    companion object {
        val ENDPOINT = "https://raw.githubusercontent.com/iMofas/ios-android-test/master/"
        val IMAGE_ENDPOINT = "https://github.com/iMofas/ios-android-test/raw/master/"
        val SORT = "sort"
        val DESC = "desc"
        val JSON = ".json"
    }
}