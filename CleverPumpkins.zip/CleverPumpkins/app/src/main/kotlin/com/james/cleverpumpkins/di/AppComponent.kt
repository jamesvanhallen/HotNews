package com.james.cleverpumpkins.di

import com.james.cleverpumpkins.mvp.presenter.HotelContentPresenter
import com.james.cleverpumpkins.mvp.presenter.HotelListPresenter
import com.james.cleverpumpkins.ui.fragment.HotelContentFragment
import com.james.cleverpumpkins.ui.fragment.HotelsListFragment
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component(modules = arrayOf(AppModule::class, NetworkModule::class))
interface AppComponent {

    fun inject(obj: HotelListPresenter)
    fun inject(obj: HotelContentPresenter)

}