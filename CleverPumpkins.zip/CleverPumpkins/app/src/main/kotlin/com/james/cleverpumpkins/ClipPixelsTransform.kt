package com.james.cleverpumpkins

import android.graphics.Bitmap
import com.squareup.picasso.Transformation

class ClipPixelsTransform : Transformation {
    override fun transform(source: Bitmap): Bitmap {
        val width = source.width
        val height = source.height
        val bitmap = Bitmap.createBitmap(source, 12, 12, width - 26, height - 26)
        if (bitmap != source) {
            source.recycle()
        }

        return bitmap
    }

    override fun key(): String {
        return ClipPixelsTransform::class.java.simpleName
    }
}