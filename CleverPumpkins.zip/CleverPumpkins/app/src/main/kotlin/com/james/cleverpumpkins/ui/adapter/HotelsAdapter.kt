package com.james.cleverpumpkins.ui.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.james.cleverpumpkins.R
import com.james.cleverpumpkins.mvp.model.Hotel
import kotlinx.android.synthetic.main.item_hotel.view.*
import java.util.*

class HotelsAdapter(var listener: (Hotel) -> Unit) : RecyclerView.Adapter<HotelsAdapter.ViewHolder>() {

    var list: List<Hotel> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HotelsAdapter.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val v = inflater.inflate(R.layout.item_hotel, parent, false)
        return HotelsAdapter.ViewHolder(v)
    }

    override fun onBindViewHolder(holder: HotelsAdapter.ViewHolder, position: Int) {
        val news = list[position]
        holder.bind(news, listener)

    }

    override fun getItemCount(): Int {

        return list.size
    }

    fun setItems(newses: List<Hotel>) {
        this.list = newses
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bind(hotel: Hotel, listener: (Hotel) -> Unit) {

            itemView.name.text = hotel.name

            itemView.address.text = hotel.address

            itemView.suits.text = itemView.context.getString(R.string.available_count, hotel.suitsCount)

            itemView.stars.showStars(hotel.stars)

            itemView.distance.text = itemView.context.getString(R.string.distance, hotel.distance)

            itemView.card_view.setOnClickListener { listener(hotel) }
        }
    }
}