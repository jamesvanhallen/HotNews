package com.james.cleverpumpkins.mvp.view

import com.arellomobile.mvp.MvpView
import com.arellomobile.mvp.viewstate.strategy.AddToEndSingleStrategy
import com.arellomobile.mvp.viewstate.strategy.StateStrategyType
import com.james.cleverpumpkins.mvp.model.Hotel

@StateStrategyType(value = AddToEndSingleStrategy::class)
interface HotelsListView : MvpView {

    fun onSuccess(list: List<Hotel>)
    fun onEmptyData()
    fun onError(error: Throwable)
    fun cancelProgress()
    fun showProgress()
    fun onNetworkFail()

}