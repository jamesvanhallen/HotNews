package com.james.cleverpumpkins.mvp.view

import com.arellomobile.mvp.MvpView
import com.arellomobile.mvp.viewstate.strategy.AddToEndSingleStrategy
import com.arellomobile.mvp.viewstate.strategy.StateStrategyType
import com.james.cleverpumpkins.mvp.model.Hotel

@StateStrategyType(value = AddToEndSingleStrategy::class)
interface HotelDetailsView : MvpView {

    fun onSuccess(hotel: Hotel)
    fun onError(error: Throwable)

}