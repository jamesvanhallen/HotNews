package com.james.cleverpumpkins.mvp.presenter

import com.arellomobile.mvp.InjectViewState
import com.james.cleverpumpkins.App
import com.james.cleverpumpkins.Const
import com.james.cleverpumpkins.api.Api
import com.james.cleverpumpkins.di.AppModule
import com.james.cleverpumpkins.mvp.view.HotelDetailsView
import rx.Scheduler
import javax.inject.Inject
import javax.inject.Named

@InjectViewState
class HotelContentPresenter(val id: Long) : RxPresenter<HotelDetailsView>() {

    @Inject
    lateinit var api: Api

    @field:[Inject Named(AppModule.MAIN_SCHEDULER)]
    lateinit var uiScheduler: Scheduler

    @field:[Inject Named(AppModule.IO_SCHEDULER)]
    lateinit var ioScheduler: Scheduler

    init {
        App.appComponent.inject(this)
        loadHotel(id)
    }

    private fun loadHotel(id: Long) {

        val sub = api.getHotel(id.toString() + Const.JSON)
                .observeOn(uiScheduler)
                .subscribeOn(ioScheduler)
                .subscribe({
                    hotel ->
                    run {
                        viewState.onSuccess(hotel)
                    }

                }, { throwable ->
                    run {
                        viewState.onError(throwable)
                    }
                })

        mainSubscription.add(sub)
    }
}