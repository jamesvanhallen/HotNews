package com.james.cleverpumpkins.di

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.james.cleverpumpkins.Const
import com.james.cleverpumpkins.api.Api
import com.james.cleverpumpkins.mvp.model.Hotel
import com.james.cleverpumpkins.mvp.model.deserializer.HotelsDeserializer
import dagger.Module
import dagger.Provides
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
class NetworkModule {

    @Provides
    @Singleton
    fun provideGson(): Gson {
        return GsonBuilder()
                .setPrettyPrinting()
                .registerTypeAdapter(Hotel::class.java, HotelsDeserializer())
                .serializeNulls()
                .create()
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val logger = HttpLoggingInterceptor()
        logger.level = HttpLoggingInterceptor.Level.BODY
        val client = OkHttpClient.Builder()
                .addInterceptor(logger)
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)

        return client.build()

    }

    @Provides
    @Singleton
    fun provideApi(client: OkHttpClient, gson: Gson): Api {

        val builder = Retrofit.Builder()
                .baseUrl(Const.ENDPOINT)
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(client)

        return builder.build().create(Api::class.java)
    }
}
