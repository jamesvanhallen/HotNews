package com.james.cleverpumpkins.mvp.presenter

import android.content.SharedPreferences
import com.arellomobile.mvp.InjectViewState
import com.james.cleverpumpkins.App
import com.james.cleverpumpkins.Const
import com.james.cleverpumpkins.api.Api
import com.james.cleverpumpkins.di.AppModule
import com.james.cleverpumpkins.mvp.model.Hotel
import com.james.cleverpumpkins.mvp.view.HotelsListView
import io.realm.Realm
import io.realm.Sort
import rx.Scheduler
import rx.Subscription
import javax.inject.Inject
import javax.inject.Named

@InjectViewState
class HotelListPresenter(val isOnline: Boolean) : RxPresenter<HotelsListView>() {

    @Inject
    lateinit var api: Api

    @Inject
    lateinit var realm: Realm

    @Inject
    lateinit var prefs: SharedPreferences

    @field:[Inject Named(AppModule.MAIN_SCHEDULER)]
    lateinit var uiScheduler: Scheduler

    @field:[Inject Named(AppModule.IO_SCHEDULER)]
    lateinit var ioScheduler: Scheduler

    var realmSubscription: Subscription? = null

    init {
        App.appComponent.inject(this)
        onRefresh(isOnline, true)
        val sortFactor = getSortFactor()
        val desc = isDesc()
        onSelectedItemClicked(sortFactor, desc)
    }

    private fun getSortFactor(): String {
        return prefs.getString(Const.SORT, Hotel.DISTANCE)
    }

    private fun saveSortFactor(sortFactor: String) {
        prefs.edit().putString(Const.SORT, sortFactor).apply()
    }

    private fun isDesc(): Boolean {
        return prefs.getBoolean(Const.DESC, true)
    }

    private fun saveDesc(desc: Boolean) {
        prefs.edit().putBoolean(Const.DESC, desc).apply()
    }

    fun onRefresh(isOnline: Boolean, showProgress: Boolean) {
        if (!isOnline) {
            viewState.onNetworkFail()
            return
        }
        if (showProgress) viewState.showProgress()
        val sub = api.getHotelsList()
                .observeOn(uiScheduler)
                .subscribeOn(ioScheduler)
                .subscribe({
                    newsList ->
                    run {
                        cancelProgress()
                        if (newsList.isNotEmpty()) {
                            realm.executeTransaction { realm -> realm.insertOrUpdate(newsList) }
                        }
                    }

                }, { throwable ->
                    run {
                        cancelProgress()
                        viewState.onError(throwable)
                    }
                })

        mainSubscription.add(sub)

    }

    fun onSelectedItemClicked(orderBy: String, desc: Boolean) {
        loadHotelsFromDB(orderBy, desc)
    }

    private fun loadHotelsFromDB(orderBy: String, desc: Boolean) {
        saveSortFactor(orderBy)
        saveDesc(desc)
        val sort = if (desc) Sort.DESCENDING else Sort.ASCENDING
        realmSubscription?.unsubscribe()
        realmSubscription = realm.where(Hotel::class.java)
                .findAllSortedAsync(orderBy, sort)
                .asObservable()
                .filter { result -> result.isLoaded }
                .subscribe({
                    listFromDB ->
                    run {
                        if (listFromDB.isNotEmpty()) {
                            viewState.onSuccess(listFromDB)
                        } else {
                            viewState.onEmptyData()
                        }
                    }
                }, { throwable ->
                    run {
                        viewState.onError(throwable)
                    }
                })
        mainSubscription.add(realmSubscription)
    }

    fun cancelProgress() {
        viewState.cancelProgress()
    }
}