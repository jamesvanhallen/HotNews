package com.james.cleverpumpkins.mvp.model

import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import java.io.Serializable

open class Hotel : RealmObject(), Serializable {

    companion object {
        const val DISTANCE = "distance"
        const val SUITES = "suites_availability"
        const val SUITES_COUNT = "suitsCount"
    }

    @PrimaryKey
    var id: Long = 0

    var name: String = ""

    var address: String = ""

    var stars: Int = 0

    var distance: Double = 0e10

    @SerializedName(SUITES)
    var suits: String = ""

    var suitsCount: Int = 0

    var image: String = ""

    var lat: Double = 0e10

    var lon: Double = 0e10
}