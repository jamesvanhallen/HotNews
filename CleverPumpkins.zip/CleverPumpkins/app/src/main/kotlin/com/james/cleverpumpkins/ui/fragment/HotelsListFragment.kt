package com.james.cleverpumpkins.ui.fragment

import android.app.ProgressDialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.widget.LinearLayoutManager
import android.view.*
import com.arellomobile.mvp.MvpAppCompatFragment
import com.arellomobile.mvp.presenter.InjectPresenter
import com.arellomobile.mvp.presenter.ProvidePresenter
import com.james.cleverpumpkins.*
import com.james.cleverpumpkins.mvp.model.Hotel
import com.james.cleverpumpkins.mvp.presenter.HotelListPresenter
import com.james.cleverpumpkins.mvp.view.HotelsListView
import com.james.cleverpumpkins.ui.activity.MainActivity
import com.james.cleverpumpkins.ui.adapter.HotelsAdapter
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_hotels_list.*

class HotelsListFragment : MvpAppCompatFragment(), HotelsListView {

    @InjectPresenter
    lateinit var hotelListPresenter: HotelListPresenter

    lateinit var adapter: HotelsAdapter

    private lateinit var dialog: ProgressDialog

    private var snack: Snackbar? = null

    companion object {

        fun newInstance(): HotelsListFragment {
            return HotelsListFragment()
        }
    }

    @ProvidePresenter
    fun providePresenter(): HotelListPresenter {
        return HotelListPresenter(activity.isOnline())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = HotelsAdapter { onItemSelected(it) }
        dialog = ProgressDialog(activity, R.style.CustomDialog)
        dialog.window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        (activity as MainActivity).let { activity ->
            activity.supportActionBar?.let { actionBar ->
                actionBar.setDisplayHomeAsUpEnabled(false)
                actionBar.setHomeButtonEnabled(false)
            }
            activity.toolbar.title = getString(R.string.app_name)
        }
        setHasOptionsMenu(true)
        return inflater.inflate(R.layout.fragment_hotels_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView.layoutManager = LinearLayoutManager(activity)
        recyclerView.adapter = adapter
        refresh.setOnRefreshListener { hotelListPresenter.onRefresh(activity.isOnline(), false) }
        refresh.setColorSchemeResources(
                R.color.colorPrimary,
                R.color.colorPrimaryDark)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        menu.clear()
        inflater.inflate(R.menu.aort_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.distance -> {
                hotelListPresenter.onSelectedItemClicked(Hotel.DISTANCE, false)
                return true
            }
            R.id.suits -> {
                hotelListPresenter.onSelectedItemClicked(Hotel.SUITES_COUNT, true)
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onSuccess(list: List<Hotel>) {
        empty.hide()
        recyclerView.show()
        adapter.setItems(list)
    }

    override fun onEmptyData() {
        recyclerView.hide()
        empty.show()
        empty.text = getString(R.string.nothing_to_show)
    }

    override fun onError(error: Throwable) {
        showSnackBar(httpErrorHandler(activity, error))
    }

    override fun cancelProgress() {
        refresh.isRefreshing = false
        dialog.apply {
            dialog.dismiss()
        }
    }

    override fun showProgress() {
        dialog.apply {
            dialog.show()
        }
    }

    fun onItemSelected(hotel: Hotel) {
        if ((activity as MainActivity).isOnline()) {
            snack?.dismiss()
            (activity as MainActivity).addFragment(HotelContentFragment.newInstance(hotel.id))
        } else {
            showSnackBar(getString(R.string.not_online))
        }
    }

    private fun showSnackBar(text: String) {
        snack = Snackbar.make(recyclerView, text, Snackbar.LENGTH_INDEFINITE)
        snack?.apply {
            setWhiteText()
            setAction(getString(R.string.snack_bar_action)) { hotelListPresenter.onRefresh(activity.isOnline(), true) }
            show()
        }
    }

    override fun onNetworkFail() {
        showSnackBar(getString(R.string.not_online))
    }
}



