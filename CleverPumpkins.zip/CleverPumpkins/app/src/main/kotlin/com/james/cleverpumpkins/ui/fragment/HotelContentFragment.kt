package com.james.cleverpumpkins.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.arellomobile.mvp.MvpAppCompatFragment
import com.arellomobile.mvp.presenter.InjectPresenter
import com.arellomobile.mvp.presenter.ProvidePresenter
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.james.cleverpumpkins.ClipPixelsTransform
import com.james.cleverpumpkins.Const
import com.james.cleverpumpkins.R
import com.james.cleverpumpkins.httpErrorHandler
import com.james.cleverpumpkins.mvp.model.Hotel
import com.james.cleverpumpkins.mvp.presenter.HotelContentPresenter
import com.james.cleverpumpkins.mvp.view.HotelDetailsView
import com.james.cleverpumpkins.ui.activity.MainActivity
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_hotel_details.*

class HotelContentFragment : MvpAppCompatFragment(), HotelDetailsView, OnMapReadyCallback {

    @InjectPresenter
    lateinit var hotelContentPresenter: HotelContentPresenter

    @ProvidePresenter
    fun providePresenter(): HotelContentPresenter {
        val id = arguments.getLong(ID)
        return HotelContentPresenter(id)
    }

    private var map: GoogleMap? = null
    private var hotel: Hotel? = null

    companion object {

        const val ID = "id"
        const val HOTEL = "hotel"

        fun newInstance(id: Long): HotelContentFragment {
            val b: Bundle = Bundle()
            b.putLong(ID, id)
            val newsContentFragment = HotelContentFragment()
            newsContentFragment.arguments = b
            return newsContentFragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hotel = (savedInstanceState?.getSerializable(HOTEL) as Hotel?)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        (activity as MainActivity).let { activity ->
            activity.supportActionBar?.let { actionBar ->
                actionBar.setDisplayHomeAsUpEnabled(false)
                actionBar.setHomeButtonEnabled(false)
            }
        }
        return inflater.inflate(R.layout.fragment_hotel_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        mapView.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putSerializable(HOTEL, hotel)
        super.onSaveInstanceState(outState)
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onMapReady(map: GoogleMap) {
        this.map = map
        hotel?.let { initMarker(it) }
    }

    private fun initMarker(hotel: Hotel) {
        val lat = hotel.lat
        val lon = hotel.lon
        val latLan = LatLng(lat, lon)
        val marker = MarkerOptions().position(latLan).title(hotel.address)
        map?.addMarker(marker)
        val camPos = CameraPosition.Builder().target(latLan).zoom(17f).build()
        map?.animateCamera(CameraUpdateFactory.newCameraPosition(camPos))
    }

    private fun initViews(hotel: Hotel) {
        (activity as MainActivity).toolbar.title = hotel.name
        addressTv.text = hotel.address
        distanceTv.text = getString(R.string.distance, hotel.distance)
        suitsTv.text = getString(R.string.available_suits, hotel.suits.replace(":", " "))
        stars.showStars(hotel.stars)

    }

    private fun setImage(hotel: Hotel) {
        val imageUrl = Const.IMAGE_ENDPOINT + hotel.image
        Picasso.with(activity)
                .load(imageUrl)
                .transform(ClipPixelsTransform())
                .fit()
                .centerInside()
                .into(image)
    }

    override fun onSuccess(hotel: Hotel) {
        this.hotel = hotel
        setImage(hotel)
        initViews(hotel)
        mapView.getMapAsync(this)
    }

    override fun onError(error: Throwable) {
        val error = httpErrorHandler(activity, error)
        Toast.makeText(activity, error, Toast.LENGTH_LONG).show()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    override fun onDestroyView() {
        mapView.onDestroy()
        map?.clear()
        super.onDestroyView()
    }
}